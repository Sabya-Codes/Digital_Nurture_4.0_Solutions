import React from 'react';

function BlogDetails() {
  return (
    <div>
      <h2>📝 Blog Details</h2>
      <p>Title: Learning React</p>
      <p>By: Sujeet Panda</p>
    </div>
  );
}

export default BlogDetails;
